import org.apache.hadoop.io.LongWritable
import org.apache.hadoop.hive.ql.exec.UDF


class Convert extends UDF{
  
  

  def evaluate(n: LongWritable): String = {
    Option(n)
      .map { num =>
        // Use Scala string interpolation. It's the easiest way, and it's
        // type-safe, unlike String.format().
        f"0x${num.get}%x"
      }
      .getOrElse("")
  }

}