

object Don extends App{
  
//  val level_3_segments = "'Americal Airlines', 'Apple', 'Arrival', 'Aspiring Prime', 'JetBlue Airways', 'Luxury Card', 'Other Airlines', 'Other Branded Cards', 'Other Partnerships', 'Other T&E', 'Ring', 'Upromise'"
//  val segmentSet = level_3_segments.replace("'", "").split(",").toList
//  println(segmentSet.contains("Americal Airlines"))
//  var a = Map("ashok" -> 12)
//  a.contains("Ashok")
  var a = 39008 > 333L
      println(a)
  
//  
  
}