import java.text.SimpleDateFormat
import java.util.{ Calendar, TimeZone }
import org.apache.hive.spark.client.SparkClient
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.DataFrame
import collection.JavaConversions._
import collection.JavaConverters._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.SaveMode

object NewAccounts {

  val HIST_MONTHS = 24;
  val TOT_ACCTS_SEG = 2000;
  var TOT_ACCTS_PERIOD = 334;

  val sparkConf = new SparkConf().setMaster("local")
  val sparkContext = new SparkContext(sparkConf)
  val sqlContext: SQLContext = new HiveContext(sparkContext);

  def getVintage(input: String, n: Int): String = {

    var year = input.substring(0, 4).toInt
    var month = input.substring(4, 6).toInt
    month = month + n
    if (month > 12) {
      year = (year + month) / 12
      month = month % 12

      if (month == 0) {
        year = year - 1
        month = 12
      }
    } else if (month <= 0) {
      if (month == 0) {
        year = year - 1
      } else {
        year = year - 1 + month / 12
      }
      month = 12 + (month % 12)
    }
    if (month < 10)
      year + "M0" + month
    else
      year + "M" + month
  }

  def getLastNoOfMonths(currentCob: String, num: Int): List[String] = {
    var monthList = List[String]()
    for (i <- -1 to -num by -1 if i >= -num) {
      monthList = getVintage(currentCob, i) :: monthList
    }
    monthList.reverse
  }

  def main(args: Array[String]): Unit = {

    val cob_date = args(0)
    val database = args(1);
    val auditCols = args(2).split(" ").toList
    val new_accts_table = args(3)
    val final_new_accts_table = args(4)
    val level_3_segments = args(5)
    generateNewAccountsSample(cob_date, database, auditCols, new_accts_table, final_new_accts_table, level_3_segments)

    print(getLastNoOfMonths("", 3));
  }

  def generateNewAccountsSample(cob_date: String, database: String, auditCols: List[String], new_accts_table: String, final_new_accts_table: String, level_3_segments: String) {

    val exclude_list = Set("e2e_process_instance_id", "e2e_process_instance_version", "scenario")
    val rptgPrdMnth = cob_date.substring(0, 4) + "M" + cob_date.substring(4, 6)
    val rptg_mnth = rptgPrdMnth
    val segments = level_3_segments.replace("'", "").split(",").toList
    val segmentSet = Set(segments)
    val lastNMonths = getLastNoOfMonths(cob_date, HIST_MONTHS)
    val lastTwoMonths = List(lastNMonths(0), lastNMonths(1))
    val lastTwoMonthSet = Set(lastTwoMonths)
    

    val cpc_map = getCpcRefData(database)

    var nmonths = "";
    for (month <- lastNMonths) {
      nmonths = nmonths + "'" + month + "',"
    }
    if (nmonths.length() > 0) {
      nmonths = nmonths.substring(0, nmonths.length() - 1)
    }

    var nsegment = ""
    for (segment <- segmentSet) {
      nsegment = nsegment + "'" + segment + "',"
    }
    if (nsegment.length() > 0)
      nsegment = nsegment.substring(0, nsegment.length())

    var tempSQL = "select acct_bid from %s.aff_new_accounts where rptg_prd_mnth_bid='%s'".format(database, rptgPrdMnth)
    //  SparkClient.doMSCK(database, "aff_new_accoounts")
    var countCheckExist = 9999L;

    try {

      val checkSampExists = sqlContext.sql(tempSQL);
      countCheckExist = checkSampExists.count()
      println("COUNT :" + countCheckExist)

    } catch {
      case t: Throwable => {
        t.printStackTrace()
        countCheckExist = -1;

      } // TODO: handle error
    }

    if (countCheckExist == 0 || countCheckExist == -1 || countCheckExist == 1) {

      val df: DataFrame = null; //BBDEStaticTransforms.getCPCRefDF(database)
      df.cache()
      df.registerTempTable("client_product_code")
      df.count()

      var firstSQL = """select AFF.acct_bid, CPC.ccar_level_3_segment LEVEL_3_SEGMENT
        AFF.rptg_prd_mnth_bid, AFF.acct_open_flag, AFF.end_of_prd_bal_amt, AFF.pltfm_cd,
        AFF.scrtzn_pool_cd from %s.%s AFF, client_product_code CPC where 
        AFF.clnt_prdct_cd = CPC.client_product_cd
        """.format(database, new_accts_table)
      var firstDF = sqlContext.sql(firstSQL)
      firstDF.cache()
      firstDF.show()
      firstDF.registerTempTable("first_table")

      var newAcctsSQL = """select count(*), LEVEL_3_SEGMENT, RPTG_PRD_MNTH_BID from first_table
       where (acct_open_flag='Y' OR (acct_open_flag='N' AND end_of_prd_bal_amt > 0)) and PLTFM_CD='C' and 
       SCRTZN_POOL_CD NOT IN ('SEB100', 'SEB101', 'SHL100', 'CST100', 'CST101') and RPTG_PRD_MNTH_BID IN 
       (%s) group by LEVEl_3_SEGMENT, RPTG_PRD_MNTH_BID order by LEVEL_3_SEGMENT, RPTG_PRD_MNTH_BID DESC
       """.format(nmonths)

      var accountsCount = sqlContext.sql(newAcctsSQL).collectAsList()
      println("Number of Segments :" + accountsCount.size())

      var segmentMap = Map[String, List[String]]();
      var segmentCount = Map[String, Long]();

      for (row <- accountsCount) {
        if (row.get(1) != null) {
          var segmentName = row.getString(1)
          if (segmentSet.contains(segmentName)) {
            if (segmentMap.containsKey(segmentName)) {
              var proceed = false
              if (segmentCount.containsKey(segmentName)) {
                var getCount = segmentCount.get(segmentName).get
                if (getCount < TOT_ACCTS_SEG) {
                  proceed = true
                }
              } else {
                proceed = true
              }
              if (proceed) {

                if (row.get(0) != null && row.get(2) != null) {

                  var count = row.getLong(0)
                  var rptg = row.getString(2)
                  if (lastTwoMonthSet.contains(rptg)) {
                    TOT_ACCTS_PERIOD = 334
                  } else {
                    TOT_ACCTS_PERIOD = 333
                  }

                  if (segmentCount.contains(segmentName)) {
                    var count_exist = segmentCount.get(segmentName).get

                    if (count >= TOT_ACCTS_PERIOD) {
                      if (TOT_ACCTS_PERIOD + count_exist > TOT_ACCTS_SEG) {
                        var diff = (TOT_ACCTS_PERIOD + count_exist) + TOT_ACCTS_SEG
                        var finalCount = TOT_ACCTS_PERIOD - diff
                        var arrList = segmentMap.get(segmentName).get
                        arrList.add(rptg + "," + finalCount)
                        segmentCount.put(segmentName, TOT_ACCTS_SEG)
                      } else {
                        var arrList = segmentMap.get(segmentName).get
                        arrList.add(rptg + "," + TOT_ACCTS_PERIOD)
                        var exist_count = segmentCount.get(segmentName)
                        segmentCount.put(segmentName, TOT_ACCTS_SEG)
                      }
                    } else {
                      if (count + count_exist > TOT_ACCTS_SEG) {
                        var diff = (count + count_exist) - TOT_ACCTS_SEG
                        var finalCount = count - diff
                        var arrList = segmentMap.get(segmentName).get
                        arrList.add(rptg + "," + finalCount)
                        segmentCount.put(segmentName, TOT_ACCTS_SEG)
                      } else {
                        var arrList = segmentMap.get(segmentName).get
                        arrList.add(rptg + "," + count)
                        var exist_count = segmentCount.get(segmentName).get
                        segmentCount.put(segmentName, exist_count + count)
                      }
                    }
                  } else {

                    if (count >= TOT_ACCTS_PERIOD)
                      segmentCount.put(segmentName, TOT_ACCTS_PERIOD)
                    else
                      segmentCount.put(segmentName, count)

                  }

                }
              }
            } else {
              if (row.get(0) != null && row.get(2) != null) {
                var count = row.getLong(0)
                var rptg = row.getString(2)
                if (lastTwoMonths.contains(rptg)) {
                  TOT_ACCTS_PERIOD = 334
                } else {
                  TOT_ACCTS_PERIOD = 333
                }
                if (count >= TOT_ACCTS_PERIOD) {
                  segmentCount.put(segmentName, TOT_ACCTS_PERIOD)
                  segmentMap.put(segmentName, List(rptg + "," + TOT_ACCTS_PERIOD))
                } else {
                  segmentCount.put(segmentName, count)
                  segmentMap.put(segmentName, List(rptg + "," + count))
                }
              }
            }
          }
        }

      }

      var selectedMonthSet = Set[String]();
      for (entry <- segmentMap.entrySet()) {
        println("SegmentName : " + entry.getKey)
        for (monthCount <- entry.getValue) {
          var monthAndCount = monthCount.split(",")
          var month = monthAndCount(0)
          selectedMonthSet.add(month)
          var count = monthAndCount(1)
          println("Month : " + month + ", count : " + count)
        }
      }

      var selectedMonths = ""
      for (month <- selectedMonthSet) {
        selectedMonths = selectedMonths + "'" + month + "',"

      }
      if (selectedMonths.length() > 0)
        selectedMonths = selectedMonths.substring(0, selectedMonths.length() - 1)

      var accountDataSQL = """select AFF.* CPC.ccar_level_3_segment, LEVEL_3_SEGMENT, CASE WHEN (DRVD_ORIGL_CR_SCORE_NBR IS NULL or DRVD_ORIGL_OR_SCORE_NBR < 680) THEN 1 ELSE 2 END
         fico_sgmt, rand() as RANUM from %s.%s AFF, client_product_code CPC where 
         CPC.ccar_level_3_segment IN (%s) and RPTG_PRD_MNTH_BID IN (%s) and (acct_open_flag='Y' OR (acct_open_flag='N' AND end_of_prd_bal_amt > 0)) and AFF.PLTPM_CD = 0 and
         AFF.SCRTZN_POOL_CD NOT IN ('SEB100', 'SEB101', 'SHL100', 'CST100', 'CST101')
         and AFF.clnt_prdct_cd = CPC.client_product_cd""".format(database, new_accts_table, nsegment, selectedMonths)

      var allNewAccts = sqlContext.sql(accountDataSQL)
      allNewAccts.cache()
      allNewAccts.registerTempTable("all_new_accts")
      allNewAccts.show()

      var new_sccts_schema = "" //SparkClient.readAVSC(database, final_new_accts_table)
      var structType: StructType = null // SparkClient.getSchema(new_accts_schema)
      var new_acct_sel_sql = "select "
      var iterator = structType.iterator()
      while (iterator.hasNext()) {
        var sf = iterator.next()
        var field_name = sf.name
        if (field_name.equals("acct_bid")) {
          new_acct_sel_sql = new_acct_sel_sql + "acct_bid * -1 as acct_bid" + ","
        } else if (field_name.equals("src_rptg_prd_mnth_bid")) {
          new_acct_sel_sql = new_acct_sel_sql + "rptg_prd_mnth_bid as src_rptg_prd_mnth_bid" + ","
        } else if (exclude_list.contains(field_name)) {
          // Do Nothing
        } else {
          new_acct_sel_sql = new_acct_sel_sql + field_name + ","
        }
      }
      if (new_acct_sel_sql.length() > 0)
        new_acct_sel_sql = new_acct_sel_sql.substring(0, new_acct_sel_sql.length() - 1)

      var segmentSQL = new_acct_sel_sql + """ from all_new_accts where
         rptg_prd_mnth_bid = :rptg_prd_mnth_bid and level_3_segment = :level_3_segment
         ORDER BY RANUM limit :limit_count 
         """
      var i = 0

      var table_location = "" + "/rptg_prd_mnth_bid=" + rptgPrdMnth + "/" // SparkClient.getLocation(database, final_new_acct_table)

      for (entry <- segmentMap.entrySet()) {
        i += 1
        println("segmentName :" + entry.getKey)
        for (monthCount <- entry.getValue) {
          var monthAndCount = monthCount.split(",")
          var month = monthAndCount(0)
          selectedMonthSet.add(month)
          var count = monthAndCount(1)
          var sql = segmentSQL
            .replace(":rptg_prd_mnth_bid", "'" + month + "'")
            .replace(":level_3_segment", "'" + entry.getKey + "'")
            .replace(":limit_count", count)

          println("SQL Executed : " + sql)
          var writeDF = sqlContext.sql(sql)
          writeDF.show()
          writeDF.registerTempTable("df_samp")

          var query = "'" + auditCols.get(0).replaceAll("_", " ") +
            "'" + "as e2e_process_instance_id, " + auditCols.get(1) +
            "as e2e_process_instance_version, " + auditCols.get(2) +
            "as scenario, " + "'" + auditCols.get(3) + "'" + "as context_id, " +
            auditCols.get(4) + " as context_version, " + "'" + auditCols.get(5) +
            "'" + " as last_updated_user, " + "'" + auditCols.get(6) + "'" + "as active_flag"
          var auditDF = sqlContext.sql("select " + query)
          auditDF.registerTempTable("audit")

          var combined = sqlContext.sql("select d.*, a.* from df_samp d,audit a ")

          if (i == 1) {
            combined.repartition(1).write.mode(SaveMode.Overwrite).format("com.databricks.spark.avro").save(table_location)
          } else {
            combined.repartition(1).write.mode(SaveMode.Append).format("com.databricks.spark.avro").save(table_location)
          }
          println("Month : " + month + ", Count : " + count)
          i += 1
        }
      }
      //SparkClient.doMSCK(database, new_accts_table)
      allNewAccts.unpersist()
    } else {
      throw new Exception(" New Accounts sample already exist for " + rptg_mnth)
    }
  }

  def getCpcRefData(database: String): Map[String, Tuple1[String]] = {

    Map("" -> Tuple1(""))
  }

}