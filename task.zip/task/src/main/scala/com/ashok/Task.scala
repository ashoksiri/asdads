package com.ashok

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.Row
import scala.collection.mutable.ListBuffer
import scala.collection.JavaConversions._
import scala.collection.JavaConverters._
import org.apache.spark.sql.hive.HiveContext
import scala.collection.mutable.WrappedArray
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema

object Task {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  val conf = new SparkConf().setMaster("local").setAppName(this.getClass.getName)
  val sc = new SparkContext(conf)
  val sqlContext: SQLContext = new HiveContext(sc)
  import sqlContext.implicits._

  def main(args: Array[String]): Unit = {

    var df = sqlContext.read.format("com.databricks.spark.csv")
      .option("header", "true").option("inferShema", "true")
      .load("file:///home/ashok/Downloads/NA.csv")

    val zipper = udf[Seq[(java.sql.Date, Int)], Seq[java.sql.Date], Seq[Int]](_.zip(_))

    df.printSchema()
    var df_counts = df.selectExpr("`cpc.ccar_level_3_segment` as cpc",
      "TO_DATE(CAST(UNIX_TIMESTAMP(rptg_prd_mnth_bid, \"yyyyMM\") AS TIMESTAMP)) as rptg_prd_mnth")
    df_counts.registerTempTable("cpctbl")

    df_counts = df_counts.groupBy("cpc", "rptg_prd_mnth").count().orderBy(desc("rptg_prd_mnth"), asc("cpc"))
    df_counts = df_counts.groupBy("cpc")
      .agg(collect_list(struct($"rptg_prd_mnth", $"count")).as("groups"))

    var query = StringBuilder.newBuilder;
    var traffic_count_collected = df_counts.collect()
    var counter = 0;

    traffic_count_collected.zipWithIndex.foreach {
      case (row, i) => {

        val months = row.getList[GenericRowWithSchema](1)
          .map(x => (x.getDate(0), x.getLong(1)))
          .sortBy(_._1.getMonth)(Ordering[Int].reverse)

        var rowCount = 0L;
        var requiredCount = 1000L;
        val finalCount = 1000L;
        months.zipWithIndex.foreach {
          case ((date, count), index) =>
            var limit = 0L;
            if (requiredCount >= 0) {
              if (index < finalCount % 333) {
                if (count > 333L) {
                  limit = 334;
                } else {
                  limit = count;
                }
                requiredCount -= limit;

              } else {
                if (count > 333L) {

                  limit = 333
                  requiredCount -= limit;

                } else if (requiredCount > count) {
                  limit = count;
                  requiredCount -= limit
                } else {
                  limit = requiredCount
                  requiredCount -= limit
                }

              }

            }
            rowCount = rowCount + limit;

            if (limit > 0) {
              //              println("limit ", limit)
              query.append(
                //               "Select * from traffic where date_format(`Date Reported`,'dd') = "+ row.getString(0) +
                //               " and date_format(`Date Reported`,'MM') = "+ row.getString(1) +
                //               " and date_format(`Date Reported`,'YY') = "+ row.getString(2) + "limit = 333");
                "select * from cpctbl " +
                  " where cpc = '" + row.getString(0) + "'" +
                  " and rptg_prd_mnth = '" + date.toString() + "'" +
                  "DISTRIBUTE BY RAND() SORT BY RAND()  LIMIT " + limit + " ");
              if (counter != 0 || requiredCount > 0) {
                query.append("UNION ALL ")
              }
            }
            counter = counter + 1

        }
      }
    }
    val start = query.lastIndexOf("UNION ALL");

    val q = query.substring(0, start)
    print(q)
    val test_df = sqlContext.sql(q)
    test_df.groupBy("cpc").count().show()

  }

}