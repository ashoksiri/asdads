package com.ashok

import java.text.SimpleDateFormat
import java.util.{ Calendar, TimeZone }
import org.apache.hive.spark.client.SparkClient
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.DataFrame
import collection.JavaConversions._
import collection.JavaConverters._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.SaveMode
import java.util.ArrayList
import org.apache.log4j.Level
import org.apache.log4j.Logger

object NewAccounts extends App {

  val HIST_MONTHS = 24;
  val TOT_ACCTS_SEG = 2000L;
  var TOT_ACCTS_PERIOD = 334L;

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  val sparkConf = new SparkConf().setMaster("local").setAppName(this.getClass.getName)
  val sparkContext = new SparkContext(sparkConf)
  val sqlContext: SQLContext = new HiveContext(sparkContext);

  //  var cob_date = System.getenv("cob_date").toString()
  var cob_date = "20190331"
  val level_3_segments = "American Airlines,Apple,Arrival,Aspiring Prime," +
    "JetBlue Airways,Luxury Card,Other Airlines,Other Branded Cards," +
    "Other Partnerships,Other T&E,Ring,Upromise"
  val segmentSet = level_3_segments.replace("'", "").split(",").toList

  val lastNMonths = getLastNoOfMonths(cob_date, HIST_MONTHS);
  val lastTwoMonths = List(lastNMonths(0), lastNMonths(1))
  val lastTwoMonthSet = lastTwoMonths.toSet
  println(lastTwoMonthSet)
  println(lastNMonths)

  //  val newAccntsSQL = sqlContext.
  //  sql("SELECT count(*), ccar_level_3_segment, rptg_prd_mnth_bid FROM rloka.bbde_pre_loss_na_snapshot"
  //+ "where partition_date=20190331 group by ccar_level_3_segment ORDER BY ccar_level_3_segment, rptg_prd_mnth_bid desc")

  val newAccntSQL = sqlContext.read.format("com.databricks.spark.csv")
    .option("inferSchema", "true")
    .option("header", "true")
    .load("file:///home/ashok/Downloads/Rajesh.csv")

//  val accountsCount = newAccntSQL.select("*").where(newAccntSQL("ccar_level_3_segment") === "American Airlines").collectAsList()
  val accountsCount = newAccntSQL.collectAsList()
  println("Number of Segments" + accountsCount.size())

  var segmentMap = Map[String, java.util.List[String]]();
  var segmentCount = Map[String, Long]();

  println("Intially Map--->", segmentMap)
  println("Intially Count--->", segmentCount)

  //  accountsCount.foreach { x => println(x) }

  for (row <- accountsCount) {
    if (row.get(1) != null) {
      var segmentName = row.getString(1)
      if (segmentSet.contains(segmentName)) {
        if (segmentMap.containsKey(segmentName)) {
          var proceed = false
          if (segmentCount.containsKey(segmentName)) {
            var getCount = segmentCount.get(segmentName).get
            if (getCount < TOT_ACCTS_SEG) {
              proceed = true
            }
          } else {
            proceed = true
          }
          if (proceed) {

            if (row.get(0) != null && row.get(2) != null) {

              var count = row.getInt(0).toLong
              var rptg = row.getInt(2).toString
              if (lastTwoMonthSet.contains(rptg)) {
                TOT_ACCTS_PERIOD = 334L
              } else {
                TOT_ACCTS_PERIOD = 333L
              }

              if (segmentCount.contains(segmentName)) {
                var count_exist = segmentCount.get(segmentName).get
                if (count >= TOT_ACCTS_PERIOD) {
                  if (TOT_ACCTS_PERIOD + count_exist > TOT_ACCTS_SEG) {
                    var diff = (TOT_ACCTS_PERIOD + count_exist) + TOT_ACCTS_SEG
                    var finalCount = TOT_ACCTS_PERIOD - diff
                    if(finalCount < 0 ){
                      finalCount = TOT_ACCTS_SEG - count_exist
                    }
                    segmentMap.get(segmentName).get.append(rptg + "," + finalCount)
                    segmentCount = segmentCount + (segmentName -> TOT_ACCTS_SEG)
                  } else {
                    segmentMap.get(segmentName).get.append(rptg + "," + TOT_ACCTS_PERIOD)
                    var exist_count = segmentCount.get(segmentName).get
                    segmentCount = segmentCount + (segmentName -> (exist_count + TOT_ACCTS_PERIOD))
                  }
                } else {
                  println(count, count_exist, TOT_ACCTS_SEG)
                  if ((count + count_exist) > TOT_ACCTS_SEG) {
                    var diff = (count + count_exist) - TOT_ACCTS_SEG
                    var finalCount = count - diff
                    segmentMap.get(segmentName).get.append(rptg + "," + finalCount)
                    segmentCount = segmentCount + (segmentName -> TOT_ACCTS_SEG)
                  } else {
                    segmentMap.get(segmentName).get.append(rptg + "," + count)
                    var exist_count = segmentCount.get(segmentName).get
                    segmentCount = segmentCount + (segmentName -> (exist_count + count))
                  }
                }
              } else {

                if (count >= TOT_ACCTS_PERIOD)
                  segmentCount = segmentCount + (segmentName -> TOT_ACCTS_PERIOD)
                else
                  segmentCount = segmentCount + (segmentName -> count)

              }

            }
          }
        } else {
          if (row.get(0) != null && row.get(2) != null) {
            var count = row.getInt(0)
            var rptg = row.getInt(2).toString()
            if (lastTwoMonths.contains(rptg)) {
              TOT_ACCTS_PERIOD = 334L
            } else {
              TOT_ACCTS_PERIOD = 333L
            }
            if (count >= TOT_ACCTS_PERIOD) {
              segmentCount = segmentCount + (segmentName -> TOT_ACCTS_PERIOD)
              var list = new ArrayList[String]()
              list.add(rptg + "," + TOT_ACCTS_PERIOD)
              segmentMap = segmentMap + (segmentName -> list)
            } else {
              segmentCount = segmentCount + (segmentName -> count)
              var list = new ArrayList[String]()
              list.add(rptg + "," + TOT_ACCTS_PERIOD)
              segmentMap = segmentMap + (segmentName -> list)
            }
          }
        }
      }
    }

  }

  println(segmentCount)
  println(segmentMap)

  var selectedMonthSet = scala.collection.mutable.Set[String]();
  for ((key, value) <- segmentMap) {
    println("SegmentName : " + key, value)
    value.asScala.foreach(x => {
      var monthAndCount = x.split(",")
      selectedMonthSet += monthAndCount(0)
      println("Month : " + monthAndCount(0) + ", count : " + monthAndCount(1))
    })
  }

  var selectedMonths = selectedMonthSet.mkString(",")
  var nsegment = segmentSet.mkString(",")
  var database = ""
  var new_accts_table = ""

  var accountDataSQL = """select AFF.* CPC.ccar_level_3_segment, LEVEL_3_SEGMENT, CASE WHEN (DRVD_ORIGL_CR_SCORE_NBR IS NULL or DRVD_ORIGL_OR_SCORE_NBR < 680) THEN 1 ELSE 2 END
         fico_sgmt, rand() as RANUM from %s.%s AFF, client_product_code CPC where 
         CPC.ccar_level_3_segment IN (%s) and RPTG_PRD_MNTH_BID IN (%s) and (acct_open_flag='Y' OR (acct_open_flag='N' AND end_of_prd_bal_amt > 0)) and AFF.PLTPM_CD = 0 and
         AFF.SCRTZN_POOL_CD NOT IN ('SEB100', 'SEB101', 'SHL100', 'CST100', 'CST101')
         and AFF.clnt_prdct_cd = CPC.client_product_cd""".format(database, new_accts_table, nsegment, selectedMonths)

//  var allNewAccts = sqlContext.sql(accountDataSQL)
//  allNewAccts.cache()
//  allNewAccts.registerTempTable("all_new_accts")
//  allNewAccts.show()

  println(selectedMonthSet)
  println(selectedMonths)

  def getVintage(input: String, n: Int): String = {

    var year = input.substring(0, 4).toInt
    var month = input.substring(4, 6).toInt
    month = month + n
    if (month > 12) {
      year = (year + month) / 12
      month = month % 12

      if (month == 0) {
        year = year - 1
        month = 12
      }
    } else if (month <= 0) {
      if (month == 0) {
        year = year - 1
      } else {
        year = year - 1 + month / 12
      }
      month = 12 + (month % 12)
    }
    //    if (month < 10)
    //      year + "M0" + month
    //    else
    //      year + "M" + month
    if (month < 10)
      year + "0" + month
    else
      year + "" + month
    //      year + "" + month
  }

  def getLastNoOfMonths(currentCob: String, num: Int): List[String] = {
    var monthList = List[String]()
    for (i <- -1 to -num by -1 if i >= -num) {
      monthList = getVintage(currentCob, i) :: monthList
    }
    monthList.reverse
  }

}