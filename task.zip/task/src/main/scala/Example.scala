
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import java.text.SimpleDateFormat
import org.apache.spark.sql.SQLContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.Row
import scala.collection.mutable.ListBuffer
import scala.collection.JavaConversions._
import scala.collection.JavaConverters._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema

case class Result(
  sgmt_str: String,
  fico: String,
  index: String,
  start: String,
  end: String,
  per_numberofnewaccounts: Float,
  numberofopenaccounts: Float,
  percentage: Float)

object Example {

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  val conf = new SparkConf()
    .setMaster("local")
    .setAppName(this.getClass.getName)
  val sc = new SparkContext(conf)
  val sqlContext: SQLContext = new HiveContext(sc)
  sqlContext.setConf("hive.metastore.uris", "thrift://192.168.0.102:9083")
  sqlContext.sql("use default")

  //  val sqlContext:SQLContext = new SQLContext(sc)
  import sqlContext.implicits._
  val formatter = new SimpleDateFormat("yyyy'M'MM")


  def convert_Data(sgmt_str: String, fico: String, months: List[Tuple3[java.sql.Date, Int, Int]]): List[Result] = {

    var rows = ListBuffer[Result]()
    var data = months.zipWithIndex.map {
      case (tpl, index) => {
        var start = index + 1;
        var end = index + 12;

        if (months.slice(start, end).length >= 11 && end < months.length) {
          //               print(months(index),months(start),months(end))
          val index_date = months(index)._1
          val startdate = months(start)._1
          val enddate = months(end)._1
          val per_numberofnewaccounts = months.subList(start, end).map(f => f._3.toFloat).sum
          val percentage = (per_numberofnewaccounts / months(start)._2.toFloat).toFloat
          rows += Result(
            sgmt_str, fico,
            formatter.format(new java.util.Date(index_date.getTime)),
            formatter.format(new java.util.Date(startdate.getTime)),
            formatter.format(new java.util.Date(enddate.getTime)),
            per_numberofnewaccounts,
            months(start)._2,
            percentage)
        }

      }
    }
    return rows.toList
  }

  def main(args: Array[String]): Unit = {

    var card_df = sqlContext.read.table("openacc")
    var card_df2 = sqlContext.read.table("newacc")

//    card_df.printSchema
//    card_df2.printSchema
    ////    sqlContext.sql("show tables").show()

    var final_df = card_df.alias("a")
      .join(card_df2.alias("b"),
        card_df("sgmt_str") === card_df2("sgmt_str") &&
          card_df("fico") === card_df2("fico"))
      .where(
        card_df("rptg_prd_mnth_bid") === card_df2("vintage"))
      .selectExpr(
        "a.sgmt_str", "a.fico",
        "a.rptg_prd_mnth_bid",
        "TO_DATE(CAST(UNIX_TIMESTAMP(a.rptg_prd_mnth_bid, \"yyyy'M'MM\") AS TIMESTAMP)) as rptg_prd_mnth",
        "a.numberofopenaccounts",
        "b.numberofnewaccounts").orderBy(desc("rptg_prd_mnth"))

    final_df = final_df.na.fill(0, Seq("numberofnewaccounts"))
    final_df = final_df.na.fill(0, Seq("numberofopenaccounts"))

    final_df.show

    var vdf = final_df.groupBy("sgmt_str", "fico")
      .agg(collect_list(struct($"rptg_prd_mnth", $"numberofopenaccounts", $"numberofnewaccounts")).as("data"))

    val final_data = vdf.rdd.zipWithIndex.map {
      case (row, i) =>
        val months = row.getList[GenericRowWithSchema](2)
          .map(x => (x.getDate(0), x.getInt(1), x.getInt(2)))
          .sortBy(_._1.getTime)(Ordering[Long].reverse).toList
//        println(months)

        convert_Data(row.getString(0), row.getString(1), months)

    }.flatMap { x => x }.toDF()
    final_data.coalesce(1).write.format("com.databricks.spark.csv")
    .option("header", "true")
    .save("file:///home/ashok/sparkjobs/data")


  }

}