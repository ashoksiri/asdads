import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.hive.ql.parse.HiveParser_FromClauseParser.splitSample_return;


public class BBDNewAccrountSelection {

	private static final int HIST_MONTHS = 14;
	private static final long TOT_ACCTS_SEG = 2000;
	private static final long TOT_ACCTS_PERIOD = 334;
	
	public static List<String> getLastNoOfMonths(String currentCob, int num){
		
		List<String> monthList = new ArrayList<String>();
		for (int i = -1; i>= -num; i--){
			
			monthList.add("");
		}
		
		return monthList;
	}
	
	public static void main(String[] args) throws Exception{
		
		String cob_Date = args[0];
		final String database = args[1];
		final ArrayList<String> auditCols = new ArrayList<String>(Arrays.asList(args[2].split(" ")));
		String new_accts_table = args[3];
		String final_new_accts_table = args[4];
		String level_3_segments = args[5];
		generateNewAccountsSample(cob_Date, database, auditCols, new_accts_table, final_new_accts_table, level_3_segments);
				
		
		
	}

	public static void generateNewAccountsSample(String cob_Date,
			String database, ArrayList<String> auditCols,
			String new_accts_table, String final_new_accts_table,
			String level_3_segments) {
		// TODO Auto-generated method stub
		
		Set<String> exclude_list = 
				new HashSet<String>(Arrays.asList(new String[]{""}));
		System.out.println("Audit Cols " + auditCols + ", Length : "+ auditCols.size());
		String rptgPrdMnth = cob_Date.substring(0,4) + "M" + cob_Date.substring(4,6);
		final String rptg_mnth = rptgPrdMnth;
		String[] segments = level_3_segments.replace("'", "").split(",");
		Set<String> segmentSet = new HashSet<String>(Arrays.asList(segments));
		List<String> lastNMonths = getLastNoOfMonths(cob_Date, HIST_MONTHS);
		String[] lastTwoMonths = new String[2];
		lastTwoMonths[0] = lastNMonths.get(0);
		lastTwoMonths[1] = lastNMonths.get(1);
		
//		final Map<String, CPCModel> cpc_map = 
		
		
		
		
	} 
	
}
